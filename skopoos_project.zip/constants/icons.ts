import skopoosLogo from "@/assets/icons/Skopoos.png";
import posLogo from "@/assets/icons/book.png";


export const icons = {
  skopoosLogo,
  posLogo,
};
