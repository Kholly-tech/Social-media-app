import image1 from '@/assets/images/1.jpg';

export const images = {
    image1,
};