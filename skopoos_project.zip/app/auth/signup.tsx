import { View, Text, Image, TextInput } from "react-native";
import React from "react";
import { icons } from "@/constants/icons";

const Signup = () => {
  return (
    <View className="flex items-center text-center justify-start pt-16 px-10">
      <View className="w-full max-w-[300px] items-center mb-8">
        {/* Set max width */}
        <Image
          source={icons.skopoosLogo}
          resizeMode="contain"
          className="w-full h-32" // Keep the height as needed
        />
      </View>
      <Text className="text-3xl font-bold text-center">Welcome to Skopoos!</Text>
      <Text className="text-lg font-normal text-center">Find Purpose, Join Skopoos to communicate with your loved ones.</Text>

      <View>
        <View className="flex-row gap-2">
            <TextInput placeholder="First Name" id="firstname" className="p-3 border border-gray-300 rounded-lg w-1/2" />
            <TextInput placeholder="Last Name" id="lastname" className="p-3 border border-gray-300 rounded-lg w-1/2" />
        </View>
        <TextInput placeholder="Phone Number" keyboardType="numeric"
      </View>
    </View>
  );
};

export default Signup;
