export const images = [
    { src: "/api/placeholder/400/400", alt: "Microphone setup", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Desktop workspace", type: "video" },
    { src: "/api/placeholder/400/400", alt: "Person by water", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Cartoon character", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Headphones and laptop", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Smart speaker with plants", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Coin and marker", type: "video" },
    { src: "/api/placeholder/400/400", alt: "Gold microphone", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Group of friends", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Hands in circle", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Person by water duplicate", type: "image" },
    { src: "/api/placeholder/400/400", alt: "Cartoon character duplicate", type: "image" }
  ];